using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Wall.Models
{
    public class CommentsandQuotes
    {
        public ValidationComment VC {get;set;}
        public List<ValidationQuote> VQ {get;set;}
    }
}