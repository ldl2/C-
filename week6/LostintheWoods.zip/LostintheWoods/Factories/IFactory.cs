using LostintheWoods.Models;
using System.Collections.Generic;
namespace LostintheWoods.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {
    }
}