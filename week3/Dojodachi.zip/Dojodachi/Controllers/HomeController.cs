using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Dojodachi.Controllers
{
    public class HomeController : Controller
    {
        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Start()
        {
            Dojodachi newdojodachi = new Dojodachi();
            HttpContext.Session.SetObjectAsJson("TheList", newdojodachi);
            return Redirect("dojodachi");
        }
        [HttpGet]
        [Route("dojodachi")]
        public IActionResult Game()
        {
            Dojodachi dach = HttpContext.Session.GetObjectFromJson<Dojodachi>("TheList");
            System.Console.WriteLine(dach.winner);
            @ViewBag.winner = dach.winner;
            @ViewBag.State = dach.State;
            @ViewBag.energy = dach.energy;
            @ViewBag.happiness = dach.happiness;
            @ViewBag.fullness = dach.fullness;
            @ViewBag.meals = dach.meals;
            return View("Index");
        }
        [HttpPost]
        [Route("button/{id}")]
        public IActionResult Index(int id)
        {
            Dojodachi changy = HttpContext.Session.GetObjectFromJson<Dojodachi>("TheList");
            if(id==1)
            {
                changy = changy.Feeding();
            }
            else if(id == 2)
            {
                changy = changy.Play();
            }
            else if(id == 3)
            {
                changy = changy.Working();
            }
            else if(id == 4)
            {
                changy = changy.Sleeping();
            }
            else
            {
                return Redirect("/");
            }
            HttpContext.Session.SetObjectAsJson("TheList", changy);
            return Redirect("/dojodachi");
        }
        
    }
    public class Dojodachi
    {
        public int happiness;
        public int fullness;
        public int energy;
        public int meals;
        public string State;
        public bool winner=false;
        public Dojodachi()
        {
            happiness = 20;
            fullness = 20;
            energy = 50;
            meals = 3;
        }
        public Dojodachi Play()
        {
            if(this.energy<5){
                this.State = " You need more energy than this";
                return this;
            }
            else{
                this.energy-=5;
                Random DeltaHappiness = new Random();
                int ChangeHappiness = DeltaHappiness.Next(5,10);
                this.happiness += BadLuck(ChangeHappiness);
                String State = $"You played with your Dojodachi and energy went down 5 while happiness increased {ChangeHappiness}";
                return this.win();
            }
        }
        public Dojodachi Feeding()
        {
            if(this.meals==0)
            {
                this.State ="You need meals to do this";
                return this;
            }
            else
            {
                this.meals -= 1;
                Random DeltaFullness = new Random();
                int ChangeFullness = DeltaFullness.Next(5, 10);
                this.fullness += BadLuck(ChangeFullness);
                this.State = $"You fed your Dojodachi, so you are down a meal while fullness increased {ChangeFullness}";
                return this.win();
            }
        }
        public Dojodachi Working()
        {
            if(energy<5)
            {
                this.State =" You need more NRG to do this";
                return this;
            }
            else
            {
                this.energy-=5;
                Random DeltaMeals = new Random();
                int ChangeMeal = DeltaMeals.Next(1,3);
                this.meals += ChangeMeal;
                this.State = $"Your poor Dojodachi was working.  He lost 5 energy but you earned {ChangeMeal}";
                return this.win();
            }
        }
        public Dojodachi Sleeping()
        {
            
            if(this.fullness < 5 || this.happiness<5)
            {
                this.energy = 0;
                this.happiness = 0;
                this.fullness = 0;
                this.meals = 0;
                this.State = "Oh no Dojoachi has died";
                return this;
            }
            else
            {
                this.energy+=15;
                
                this.fullness-=5;
                this.happiness-=5;
                this.State = $"**Zzzzzzzz**  Dojodachi is asleep.  He gains 15 energy, and is less full and happy (-5 ea.).";
                return this.win();
            }
            
        }
        public int BadLuck(int chance)
        {
            int realluck;
            Random Luck = new Random();
            int lucky = Luck.Next(1,4);
            if(lucky ==1)
            {
                realluck = 0;
            }
            else
            {
                realluck = 1;
            }
            chance*=realluck;
            return chance;

        }
        public Dojodachi win()
        {
            if(this.energy >= 100 && this.happiness >= 100 && this.fullness >=100)
            {
                this.State = "Congratulations! You won!";
                this.winner = true;
                return this;
            }
            else
            {
                return this;
            }
        }
        
    }
    public static class SessionExtensions
        {
            // We can call ".SetObjectAsJson" just like our other session set methods, by passing a key and a value
            public static void SetObjectAsJson(this ISession session, string key, object value)
            {
                // This helper function simply serializes theobject to JSON and stores it as a string in session
                session.SetString(key, JsonConvert.SerializeObject(value));
            }
            
            // generic type T is a stand-in indicating that we need to specify the type on retrieval
            public static T GetObjectFromJson<T>(this ISession session, string key)
            {
                string value = session.GetString(key);
                // Upon retrieval the object is deserialized based on the type we specified
                return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
            }
        }
}
